QULE, now on a floppy disc for your inconvenience!

Alpha v0

What is QULE?
QULEtools, meaning Questionably Legal Tools, is a set of fun browser-based tools that 
feel shady. While your door won't actually get kicked down for using any of this, it's 
still fun to feel like you're doing something you shouldn't. Only 1 of these programs 
are actually illegal in the USA, but even then it's so scaled down that nobody would 
ever run into problems for it.