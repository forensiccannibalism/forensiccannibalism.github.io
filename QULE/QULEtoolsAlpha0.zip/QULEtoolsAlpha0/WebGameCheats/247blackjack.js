function maxMoney() {
  const key1 = "com.games247.blackjack.247.Bank";
  const data = JSON.parse(localStorage.getItem(key1));
  data.bank = 1000000000000;
  localStorage.setItem(key1, JSON.stringify(data));
  console.log(
    "%cMoney Save Updated Successfully!",
    "color: red; font-weight: bold; font-size: 16px;"
  );
  console.log(
    `%cNew Balance: $${data.bank}`,
    "color: red; font-size: 14px;"
  );
  location.reload();
}
function weirdDeck() {
  const key1 = "com.games247.blackjack.247.Deck";
  const data = JSON.parse(localStorage.getItem(key1));
  data.deckCount = 5;
  localStorage.setItem(key1, JSON.stringify(data));
  console.log(
    "%c Deck Count Updated Successfully!",
    "color: red; font-weight: bold; font-size: 16px;"
  );
  console.log(
    `%c➡ New Deck Count: $${data.deckCount}`,
    "color: red; font-size: 14px;"
  );
}
function startAdKiller() {
  const key1 = "com.games247.blackjack.GameAds";
  const key2 = "com.games247.FeatureAd";
  const data = JSON.parse(localStorage.getItem(key1));
  const data2 = JSON.parse(localStorage.getItem(key2));
  data.adPlacementOpportunities = -100;
  data.launches = -100;
  data2.totalTimesOpened = -100;
  data2.timesOpenedSinceLastAd = -100;
  data2.totalAdsShown = -100;
  data2.adIndex = -100;
  localStorage.setItem(key1, JSON.stringify(data));
  localStorage.setItem(key2, JSON.stringify(data2));
  console.log(
    "%cAds Disabled!",
    "color: red; font-weight: bold; font-size: 16px;"
  );
  console.log(
    "%cYou should no longer see ads after refreshing.",
    "color: red; font-size: 14px;"
  );
}
console.log(
  "%cAvailable Hacks:",
  "color: red; font-weight: bold; font-size: 16px;"
);
console.log(
  "%cType one of the following commands in the console to activate:",
  "color: red; font-size: 14px;"
);
console.log(
  "%c• maxMoney() – Set money to $1 Quintillion",
  "color: red; font-size: 14px;"
);
console.log(
  "%c• startAdKiller() – Disable ads on load",
  "color: red; font-size: 14px;"
);
console.log(
  "%c• weirdDeck() – Make the deck really weird (CURRENTLY BROKEN)",
  "color: red; font-size: 14px;"
);